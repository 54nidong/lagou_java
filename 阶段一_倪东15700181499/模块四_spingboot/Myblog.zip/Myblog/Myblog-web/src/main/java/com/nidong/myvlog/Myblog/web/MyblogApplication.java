package com.nidong.myvlog.Myblog.web;

import com.guahao.convention.data.domain.Result;
import com.guahao.convention.data.domain.Results;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;



import org.mybatis.spring.annotation.MapperScan;

@SpringBootApplication(scanBasePackages = {"com.nidong.myvlog.Myblog"})
@MapperScan(basePackages = { "com.nidong.myvlog.Myblog.biz.dal" })
public class MyblogApplication {

	public static void main(String[] args) {
		SpringApplication.run(MyblogApplication.class, args);
	}

	@RestController
	public static class EchoTest {

		@GetMapping("/")
		public Result<String> echo() {
			return Results.success("MyblogApplication");
		}

	}

}
