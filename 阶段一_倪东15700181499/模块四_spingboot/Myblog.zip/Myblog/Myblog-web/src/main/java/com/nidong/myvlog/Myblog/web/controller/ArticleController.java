package com.nidong.myvlog.Myblog.web.controller;

import com.guahao.convention.data.domain.Result;
import com.guahao.convention.data.domain.Results;
import com.nidong.myvlog.Myblog.biz.dal.Article;
import com.nidong.myvlog.Myblog.biz.dal.ArticleManager;
import com.nidong.myvlog.Myblog.biz.dal.PageBO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

@RestController
@RequestMapping("/api/article")
public class ArticleController {

    @Autowired
    private ArticleManager articleManager;

    @RequestMapping(value = "/selectListPage", method = RequestMethod.POST)
    public Result<PageBO> selectListPage(@RequestBody Article request) {
        Integer pageIndex = request.getPageIndex();
        Integer pageSize = request.getPageSize();
        pageIndex = pageIndex == null ? com.guahao.wecloud.biz.common.util.PageUtil.DEFAULT_PAGE_INDEX : pageIndex;
        pageSize = pageSize == null ? com.guahao.wecloud.biz.common.util.PageUtil.DEFAULT_PAGE_SIZE : pageSize;
        com.guahao.wecloud.biz.common.util.PageUtil pageUtil = new com.guahao.wecloud.biz.common.util.PageUtil();
        PageBO pageBO = pageUtil.getPageContent(pageIndex, pageSize, articleManager.selectList(request));
        return Results.success(pageBO);
    }

    @RequestMapping("/index.html")
    public ModelAndView index(ModelAndView modelAndView) {
        Result<PageBO> pageBOResult = selectListPage(null);
        modelAndView.addObject("data", pageBOResult.getData().getDataList());
        modelAndView.addObject("pageIndex", pageBOResult.getData().getPageIndex());
        modelAndView.addObject("pageSize", pageBOResult.getData().getPageSize());
        modelAndView.addObject("totalPage", pageBOResult.getData().getTotalPage());
        modelAndView.addObject("totalRecord", pageBOResult.getData().getTotalRecord());
        modelAndView.setViewName("index");
        return modelAndView;
    }
}
