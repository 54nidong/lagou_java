package com.nidong.myvlog.Myblog.biz.dal;


import java.util.List;

public interface ArticleMapper {
    List<Article> selectList(Article request);
}
