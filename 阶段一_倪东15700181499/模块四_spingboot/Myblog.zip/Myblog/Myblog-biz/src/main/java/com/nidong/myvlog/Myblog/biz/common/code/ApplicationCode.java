/*
 * Copyright (c) 2001-2018 GuaHao.com Corporation Limited. All rights reserved.
 * This software is the confidential and proprietary information of GuaHao Company.
 * ("Confidential Information").
 * You shall not disclose such Confidential Information and shall use it only
 * in accordance with the terms of the license agreement you entered into with GuaHao.com.
 */
package com.nidong.myvlog.Myblog.biz.common.code;

import com.guahao.convention.data.code.ServiceCode;

/**
 * 应用code，用于业务错误，
 *
 * 请按标准模式构建，如LOGIN_ID_ERROR ("AUTH","12000","登录ID错误")
 *
 * @author initializr
 * @version 1.0
 * @since 2020-11-10
 */
public enum ApplicationCode implements ServiceCode {
    ;

    private String code;

    private String message;

    ApplicationCode(String codeSign, String code, String message) {
        this.code = codeSign + "_" + code;
        this.message = message;
    }

    @Override
    public String code() {
        return this.code;
    }

    @Override
    public String message() {
        return this.message;
    }

}
