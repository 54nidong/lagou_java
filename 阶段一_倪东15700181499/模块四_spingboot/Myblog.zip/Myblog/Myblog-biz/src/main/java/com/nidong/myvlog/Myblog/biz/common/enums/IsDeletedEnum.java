/*
 * Copyright (c) 2001-2018 GuaHao.com Corporation Limited. All rights reserved.
 * This software is the confidential and proprietary information of GuaHao Company.
 * ("Confidential Information").
 * You shall not disclose such Confidential Information and shall use it only
 * in accordance with the terms of the license agreement you entered into with GuaHao.com.
 */
package com.nidong.myvlog.Myblog.biz.common.enums;

/**
 * 是否删除枚举
 *
 * @author initializr
 * @version 1.0
 * @since 2020-11-10
 */
public enum IsDeletedEnum {

    /**
     * 未删除
     */
    NOT_DELETED(0),

    /**
     * 已删除
     */
    IS_DELETED(1);

    private Integer code;

    IsDeletedEnum(Integer code) {
        this.code = code;
    }

    public Integer code() {
        return code;
    }
}
