package com.guahao.wecloud.biz.common.util;


import com.nidong.myvlog.Myblog.biz.common.Page;
import com.nidong.myvlog.Myblog.biz.dal.PageBO;

import java.util.ArrayList;
import java.util.List;

public class PageUtil {
    public static final Integer DEFAULT_PAGE_INDEX = 1;
    public static final Integer DEFAULT_PAGE_SIZE = 10;
    /**
     * 总记录条数
     */
    private int totalRecord = 0;
    /**
     * 每页条数
     */
    private int pageSize = 0;
    /**
     * 当前页码
     */
    private int pageIndex = 1;
    /**
     * 总页数
     */
    private int totalPage = 0;
    /**
     * 开始下标
     */
    private int pageStartRow = 0;
    /**
     * 结束下标
     */
    private int pageEndRow = 0;
    /**
     * 是否有下一页
     */
    private boolean hasNextPage = false;
    /**
     * 是否有前一页
     */
    private boolean hasPreviousPage = false;

    private List list;

    public PageUtil(List list, int pageSize) {
        init(list, pageSize);  //通过对象集，记录总数划分
    }

    public PageUtil() {
    }

    /**
     * 传入pageSize,初始化list
     */
    public void init(List list, int pageSize) {
        this.pageSize = pageSize;
        this.list = list;
        totalRecord = list.size();
        hasPreviousPage = false;
        if ((totalRecord % pageSize) == 0) {
            totalPage = totalRecord / pageSize;
        } else {
            totalPage = totalRecord / pageSize + 1;
        }

        if (pageIndex >= totalPage) {
            hasNextPage = false;
        } else {
            hasNextPage = true;
        }

        if (totalRecord < pageSize) {
            this.pageStartRow = 0;
            this.pageEndRow = totalRecord;
        }
    }

    /**
     * 判断是否分页
     */
    public boolean isNext() {
        return list.size() > 5;
    }

    public void setHasPreviousPage(boolean hasPreviousPage) {
        this.hasPreviousPage = hasPreviousPage;
    }

    /**
     * 分页
     *
     * @param page
     * @return
     */
    public List getPageData(int page) {
        if (page == 0) {
            this.setPageIndex(1);
        } else {
            this.setPageIndex(page);
        }
        if (pageIndex * pageSize < totalRecord) {
            pageEndRow = pageIndex * pageSize;
            pageStartRow = pageEndRow - pageSize;
        } else {
            pageEndRow = totalRecord;
            pageStartRow = pageSize * (totalPage - 1);
        }

        List subList = null;
        if (!list.isEmpty()) {
            subList = list.subList(pageStartRow, pageEndRow);
        }
        return subList;
    }

    /**
     * 获取分页数据，封装返回对象
     *
     * @return PageModel
     * @author fanxx 2017年01月07日 下午15:49:20
     */
    public PageBO getPageContent(int pageIndex, int pageSize, List dataList) {
        List pageData = new ArrayList<>();
        PageBO pageModel = new PageBO();
        PageUtil pageUtil = new PageUtil(dataList, pageSize);
        pageData = pageUtil.getPageData(pageIndex);
        pageModel.setDataList(pageData);
        pageModel.setPageIndex(pageIndex);
        pageModel.setPageSize(pageSize);
        pageModel.setTotalPage(pageUtil.getTotalPage());
        pageModel.setTotalRecord(pageUtil.getTotalRecord());
        if (dataList.size() == 0) {
            pageModel.setDataList(dataList);
        }
        return pageModel;
    }

    public static PageBO convertToPageResult(Page page) {
        PageBO pageResult = new PageBO();
        int pageSize = page.getPageSize();
        int totalRecord = (int) page.getTotal();
        pageResult.setDataList(page.getResult());
        pageResult.setPageIndex(page.getPageNum());
        pageResult.setPageSize(pageSize);
        pageResult.setTotalRecord(totalRecord);
        int totalPage = pageSize <= 0 ? 0 : (totalRecord + pageSize - 1) / pageSize;
        pageResult.setTotalPage(totalPage);
        return pageResult;
    }

    public int getTotalRecord() {
        return totalRecord;
    }

    public void setTotalRecord(int totalRecord) {
        this.totalRecord = totalRecord;
    }

    public int getPageSize() {
        return pageSize;
    }

    public void setPageSize(int pageSize) {
        this.pageSize = pageSize;
    }

    public int getPageIndex() {
        return pageIndex;
    }

    public void setPageIndex(int pageIndex) {
        this.pageIndex = pageIndex;
    }

    public int getTotalPage() {
        return totalPage;
    }

    public void setTotalPage(int totalPage) {
        this.totalPage = totalPage;
    }

    public int getPageStartRow() {
        return pageStartRow;
    }

    public void setPageStartRow(int pageStartRow) {
        this.pageStartRow = pageStartRow;
    }

    public int getPageEndRow() {
        return pageEndRow;
    }

    public void setPageEndRow(int pageEndRow) {
        this.pageEndRow = pageEndRow;
    }

    public boolean isHasNextPage() {
        return hasNextPage;
    }

    public void setHasNextPage(boolean hasNextPage) {
        this.hasNextPage = hasNextPage;
    }

    public boolean isHasPreviousPage() {
        return hasPreviousPage;
    }

    public List getList() {
        return list;
    }

    public void setList(List list) {
        this.list = list;
    }
}
