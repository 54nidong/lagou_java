package com.nidong.myvlog.Myblog.biz.dal;

import lombok.AccessLevel;
import lombok.Data;
import lombok.experimental.FieldDefaults;

import java.util.List;

/**
 * Created by yangshengwei on 2018/10/22
 * @author 杨胜伟
 */
@Data
@FieldDefaults(level = AccessLevel.PRIVATE)
public class PageBO {
    /**当前页码*/
    Integer pageSize;
    /**每页条数*/
    Integer pageIndex;
    /**总记录条数*/
    Integer totalRecord;
    /**总页数*/
    Integer totalPage;
    /**返回对象*/
    List dataList;
}
