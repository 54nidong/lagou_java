package com.nidong.myvlog.Myblog.biz.dal;

import java.util.List;

public interface ArticleManager {
    List<Article> selectList(Article request);
}
