package com.nidong.myvlog.Myblog.biz.dal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class ArticleManagerImpl implements  ArticleManager {

    @Autowired
    private ArticleMapper articleMapper;

    @Override
    public List<Article> selectList(Article request) {
        return articleMapper.selectList(request);
    }
}
