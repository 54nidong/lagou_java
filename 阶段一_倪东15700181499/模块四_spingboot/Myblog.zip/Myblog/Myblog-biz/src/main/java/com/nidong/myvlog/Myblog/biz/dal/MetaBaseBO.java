package com.nidong.myvlog.Myblog.biz.dal;

import lombok.AccessLevel;
import lombok.Data;
import lombok.experimental.FieldDefaults;
import java.io.Serializable;


@Data
@FieldDefaults(level = AccessLevel.PRIVATE)
public class MetaBaseBO implements Serializable {
    static final long serialVersionUID = -14347881316432222L;
    /**用户id*/
    String userId;

    /**每页大小*/
    Integer pageSize;

    /**页码*/
    Integer pageIndex;

}
